package com.example.worldcup2022;

import com.example.worldcup2022.manager.models.FixtureResponse;

public interface ReponsiveLinstener {
    void didFetch(FixtureResponse response,String message);
    void didError(String message);
}
