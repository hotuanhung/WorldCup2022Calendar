package com.example.worldcup2022.manager.models;

public class Pagenation {
     public int page;
     public int itemsPerPage;
     public boolean hasNextPage;
     public boolean hasPrevPage;
}
