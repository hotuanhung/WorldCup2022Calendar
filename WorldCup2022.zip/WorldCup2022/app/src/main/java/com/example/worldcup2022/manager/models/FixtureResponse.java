package com.example.worldcup2022.manager.models;

import java.util.ArrayList;

public class FixtureResponse {
    public ArrayList<FixtureData> data;
    public Pagenation pagination;
}
